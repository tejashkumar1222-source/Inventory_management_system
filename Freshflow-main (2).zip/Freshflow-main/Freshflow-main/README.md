# FreshFlow - Inventory Management System

A modern, dashboard-driven web application for tracking inventory freshness, reducing waste, and optimizing supply chain operations.

## Features

- **Smart Inventory Tracking**: Real-time monitoring of stock levels with automated expiry date tracking
- **Expiry Alerts**: Intelligent notifications via email, SMS, or dashboard alerts
- **Analytics & Reports**: Comprehensive insights into waste patterns and consumption trends
- **Donation Management**: Connect with NGOs and charities to donate expiring items
- **Auto Reorder**: Intelligent reorder suggestions based on consumption patterns
- **Role-Based Access**: Secure multi-user access with different permission levels

## Technology Stack

- **Backend**: Python Flask
- **Database**: MongoDB
- **Frontend**: HTML5, CSS3, JavaScript
- **Charts**: Chart.js
- **Icons**: Font Awesome
- **Fonts**: Inter (Google Fonts)

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd FreshFlow
   ```

2. **Install Python dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up MongoDB**
   - Install MongoDB on your system
   - Start MongoDB service
   - Create a database named `freshflow`

4. **Configure environment variables**
   Create a `.env` file in the root directory:
   ```
   SECRET_KEY=your-secret-key-here-change-this-in-production
   MONGO_URI=mongodb://localhost:27017/freshflow
   ```

5. **Run the application**
   ```bash
   python app.py
   ```

6. **Access the application**
   - Open your browser and go to `http://localhost:5000`
   - Default admin credentials:
     - Username: `admin`
     - Password: `admin123`

## Usage

### Getting Started

1. **Login**: Use the default admin credentials or create a new account
2. **Dashboard**: View overview of your inventory with key metrics and charts
3. **Add Inventory**: Start by adding items to your inventory
4. **Set Alerts**: Configure expiry alerts for different time periods
5. **Monitor**: Use the dashboard to track stock levels and expiry dates

### Key Pages

- **Dashboard**: Overview with statistics and recent activity
- **Inventory**: Complete inventory management with filtering and search
- **Expiry Alerts**: Color-coded timeline of items nearing expiry
- **Analytics**: Detailed reports and waste analysis
- **Orders**: Reorder suggestions and order management
- **Donations**: Manage donations to NGOs and charities
- **Settings**: User management and system configuration

### User Roles

- **Admin**: Full access to all features and user management
- **Manager**: Access to inventory, analytics, and reports
- **Warehouse Staff**: Basic inventory management and alerts

## Design System

### Color Palette
- **Fresh Green**: #27ae60 (primary actions, success states)
- **Alert Orange**: #e67e22 (warnings, expiry alerts)
- **Calm Blue**: #2980b9 (data, reports, information)
- **Text Dark**: #2c3e50 (primary text)
- **Text Light**: #7f8c8d (secondary text)

### Typography
- **Font Family**: Inter (Google Fonts)
- **Weights**: 300, 400, 500, 600, 700

### Components
- **Cards**: Rounded corners, subtle shadows, responsive grid
- **Buttons**: Modern styling with hover effects
- **Tables**: Clean, sortable, filterable data tables
- **Charts**: Interactive visualizations using Chart.js

## API Endpoints

- `GET /` - Landing page
- `GET /login` - Login page
- `POST /login` - Authenticate user
- `GET /signup` - Signup page
- `POST /signup` - Create new user
- `GET /dashboard` - Main dashboard
- `GET /inventory` - Inventory management
- `POST /inventory/add` - Add new item
- `GET /expiry-alerts` - Expiry alerts page
- `GET /analytics` - Analytics and reports
- `GET /orders` - Orders and reorders
- `GET /donations` - Donation management
- `GET /settings` - Settings page
- `GET /api/chart-data` - Chart data API

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions, please contact the development team or create an issue in the repository.

---

**FreshFlow** - Track Freshness. Save Wastage. Boost Efficiency.
